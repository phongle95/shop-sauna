<h3>Tên Khách Hàng : <?php echo e($name); ?></h3>
<h3>Số Điện Thoại : <?php echo e($sdt); ?></h3>
<h3>Địa Chỉ Email : <?php echo e($email); ?></h3>
<h3>Địa Chỉ: <?php echo e($diachi); ?></h3>
<?php /**PATH C:\xampp\htdocs\shop-sauna\resources\views/mailfb.blade.php ENDPATH**/ ?>