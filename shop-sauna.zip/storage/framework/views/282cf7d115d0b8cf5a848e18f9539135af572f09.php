<?php /* C:\xampp\htdocs\shop-sauna\resources\views/admin/pages/loaitin/danhsach.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <!-- DATA TABLE -->
      <div class="table-data__tool">
         <div class="table-data__tool-left">
            <?php if(session('thongbao')): ?>
            <div style="color:green;font-weight: 400; text-align:center">
               <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?> <?php if(session('xoa')): ?>
            <div style="color:red;font-weight: 400; text-align:center">
               <?php echo e(session('xoa')); ?>

            </div>
            <?php endif; ?>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <h4 class="card-title">Danh Sách Loại Tin</h4>
                  <p class="card-description">
                     <a href="<?php echo e(route('admin.pages.loaitin.them')); ?>" class="btn btn-inverse-info btn-fw">
                     Thêm Loại Tin</a>
                  </p>
                  <table class="table table-hover">
                     <thead>
                        <tr>
                           <th>Mã Loại Tin</th>
                           <th>Danh Mục</th>
                           <th>Sửa</th>
                           <th>Xóa</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                           <td><?php echo e($lt->id); ?></td>
                           <td><?php echo e($lt->tenLoaiTin); ?></td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.loaitin.sua',$lt->id)); ?>" class="btn btn-outline-success btn-fw"> Sửa</a>
                           </td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.loaitin.xoa',$lt->id)); ?>" class="btn btn-outline-danger btn-fw"> Xóa</a>
                           </td>
                        </tr>
                        <tr class="spacer"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
      <!-- END DATA TABLE -->
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>