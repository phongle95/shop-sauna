 <?php $__env->startSection('noidung'); ?>

<main class="main">
        <br>
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('trangchu.pages.trangchu')); ?>"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Thành Công</li>
                </ol>
            </div><!-- End .container -->
        </nav>

        <div class="container">
            <ul class="checkout-progress-bar">
                <li>
                    <span>Nhập Thông Tin</span>
                </li>
                <li class="active">
                    <span>Thành Công</span>
                </li>
            </ul>
            <h2 style="text-align:center">Đặt Hàng Thành Công</h2>
        </div><!-- End .container -->

        <div class="mb-6"></div><!-- margin -->
    </main><!-- End .main -->

<?php $__env->stopSection(); ?> <?php $__env->startSection('meta'); ?>
<title>Du Lịch Lý Sơn - Thuê Xe Đà Nẵng - Khách Sạn Lý Sơn</title>
<meta name="keywords" content="" />
<meta name="description" content='' />
<!--meta facebook-->
<meta property="og:title" content="Du Lịch Lý Sơn - Tour Lý Sơn - Thuê Xe Đà Nẵng" />
<meta property="og:description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta property="og:image" content="travel/images/dulich.jpg" />
<!--meta google-->
<meta itemprop="name" content="du lịch lý sơn chuyên tổ chức các tour du lịch lý sơn , đà nẵng , hội an , huế và cho thuê xe du lịch" />
<meta itemprop="description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta itemprop="image" content="travel/images/dulich.jpg" />
<meta name="og:url" content="<?php echo e(route('trangchu.pages.trangchu')); ?>" /> <?php $__env->stopSection(); ?>

<?php echo $__env->make('trangchu.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-sauna\resources\views/trangchu/pages/thanhcong.blade.php ENDPATH**/ ?>