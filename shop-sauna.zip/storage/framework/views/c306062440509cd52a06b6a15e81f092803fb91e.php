<?php /* C:\xampp\htdocs\lyson\resources\views/trangchu/pages/tintuc.blade.php */ ?>
 <?php $__env->startSection('noidung'); ?>
<!-- Home -->
<div class="home1">
    <div class="home_background1 parallax-window" data-parallax="scroll" data-image-src="travel/images/blog_background.jpg"></div>
    <div class="home_content1">
    </div>
</div>
<!-- Blog -->
<div class="blog">
    <div class="container">
        <div class="row">
            <!-- Blog Content -->
            <div class="col-lg-8">
                <div class="blog_post_container">
                    <!-- Blog Post -->
                    <h1 style="font-family: Times, serif;color:black; font-size: 200%;font-weight:700;text-align:center">Tin Tức Du Lịch</h1>
                    <br> <?php $__currentLoopData = $tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog_post">
                        <div class="blog_post_image">
                            <h2><a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id])); ?>"><img class="custom-img" src="/upload/<?php echo e($item->img); ?>" alt="du lịch lý sơn"></a></h2>
                            <div class="blog_post_date d-flex flex-column align-items-center justify-content-center">
                                <div class="blog_post_day"><?php echo e($item->id); ?></div>
                                <div class="blog_post_month"><?php echo e(date("d-m-Y", strtotime($item->date))); ?></div>
                            </div>
                        </div>
                        <div class="blog_post_title"><a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id])); ?>"><?php echo e($item->tieuDe); ?></a></div>
                        <div class="rating_r rating_r_4 hotel_rating">
                            <i></i>
                            <i></i>
                            <i></i>
                            <i></i>
                            <i></i>
                        </div>
                        <div class="blog_post_text">
                            <p style="text-align:left;font-weight: 600;color:#262d38"><?php echo e($item->description); ?>.</p>
                        </div>
                        <div class="blog_post_link">
                            <h3><a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id])); ?>">Xem Thêm</a></h3></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="blog_navigation">
                    <ul>
                        <li class="blog_dot">
                            <div></div>
                            <?php echo $tin->links(); ?>

                        </li>
                    </ul>
                </div>
            </div>
            <!-- Blog Sidebar -->
            <div class="col-lg-4 sidebar_col">
                    <?php echo $__env->make('trangchu.menu.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<br> <?php $__env->stopSection(); ?> <?php $__env->startSection('meta'); ?>
<title>Du Lịch Lý Sơn - Thuê Xe Đà Nẵng - Khách Sạn Lý Sơn</title>
<meta name="keywords" content="du lịch lý sơn ,tour lý sơn,du lịch lý sơn giá rẻ,du lịch quảng ngãi lý sơn,du lịch đà nẵng lý sơn , du lịch hội an lý sơn" />
<meta name="description" content='lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn' />
<!--meta facebook-->
<meta property="og:title" content="Du Lịch Lý Sơn - Tour Lý Sơn - Thuê Xe Đà Nẵng" />
<meta property="og:description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta property="og:image" content="travel/images/dulich.jpg" />
<!--meta google-->
<meta itemprop="name" content="du lịch lý sơn chuyên tổ chức các tour du lịch lý sơn , đà nẵng , hội an , huế và cho thuê xe du lịch" />
<meta itemprop="description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta itemprop="image" content="travel/images/dulich.jpg" />
<meta name="og:url" content="<?php echo e(route('trangchu.pages.tintuc')); ?>" /> <?php $__env->stopSection(); ?>

<?php echo $__env->make('trangchu.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>