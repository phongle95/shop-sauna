<?php /* C:\xampp\htdocs\shop-sauna\resources\views/admin/pages/items/danhsach.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <!-- DATA TABLE -->
      <div class="table-data__tool">
         <div class="table-data__tool-left">
            <?php if(session('thongbao')): ?>
            <div style="color:green;font-weight: 400; text-align:center">
               <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?> <?php if(session('xoa')): ?>
            <div style="color:red;font-weight: 400; text-align:center">
               <?php echo e(session('xoa')); ?>

            </div>
            <?php endif; ?>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <h4 class="card-title">Danh Sách Loại Mặt Hàng</h4>
                  <p class="card-description">
                     <a href="<?php echo e(route('admin.pages.items.them')); ?>" class="btn btn-inverse-info btn-fw">
                     Thêm Mặt Hàng</a>
                  </p>
                  <table class="table table-hover">
                     <thead>
                        <tr>
                           <th>id</th>
                           <th>Loại Mặt Hàng</th>
                           <th>Loại Sản Phẩm</th>
                           <th>Sửa</th>
                           <th>Xóa</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $mathang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                           <td><?php echo e($item->id); ?></td>
                           <td><?php echo e($item->tenMatHang); ?></td>
                           <td>
                                <?php $__currentLoopData = $loaisanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lsp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->maLoaiSanPham == $lsp->id): ?>
                                        <?php echo e($lsp->tenLoaiSanPham); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.items.sua',$item->id)); ?>" class="btn btn-outline-success btn-fw"> Sửa</a>
                           </td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.items.xoa',$item->id)); ?>" class="btn btn-outline-danger btn-fw"> Xóa</a>
                           </td>
                        </tr>
                        <tr class="spacer"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
      <!-- END DATA TABLE -->
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>