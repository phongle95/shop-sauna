<?php /* C:\xampp\htdocs\shop-sauna\resources\views/admin/pages/tin/danhsach.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <!-- DATA TABLE -->
      <div class="table-data__tool">
         <div class="table-data__tool-left">
            <?php if(session('thongbao')): ?>
            <div style="color:green;font-weight: 400; text-align:center">
               <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?> <?php if(session('xoa')): ?>
            <div style="color:red;font-weight: 400; text-align:center">
               <?php echo e(session('xoa')); ?>

            </div>
            <?php endif; ?>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <h4 class="card-title">Danh Sách Tin Tức</h4>
                  <p class="card-description">
                     <a href="<?php echo e(route('admin.pages.tin.them')); ?>" class="btn btn-inverse-info btn-fw">
                     Thêm Tin Tức</a>
                  </p>
                  <table class="table table-hover">
                     <thead>
                        <tr>
                           <th>Tiêu Đề</th>
                           <th>Hình</th>
                           <th>Danh Mục</th>
                           <th>Sửa</th>
                           <th>Xóa</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                           <td><?php echo e($new->tieuDe); ?></td>
                           <td>
                              <img style="height:150px;width:150px" src="/upload/<?php echo e($new->img); ?>" alt="lý sơn"/>
                           </td>
                           <td>
                               <?php $__currentLoopData = $loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($item->id == $new->maLoaiTin): ?>
                                       <?php echo e($item->tenLoaiTin); ?>

                                   <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.tin.sua',$new->id)); ?>" class="btn btn-outline-success btn-fw"> Sửa</a>
                           </td>
                           <td>
                              <a href="<?php echo e(route('admin.pages.tin.xoa',$new->id)); ?>" class="btn btn-outline-danger btn-fw"> Xóa</a>
                           </td>
                        </tr>
                        <tr class="spacer"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
      <!-- END DATA TABLE -->
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>