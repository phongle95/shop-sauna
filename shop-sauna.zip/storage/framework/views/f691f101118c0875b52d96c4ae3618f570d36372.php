 <?php $__env->startSection('noidung'); ?>
<main class="main">
    <br>
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Thanh Toán</li>
                </ol>
            </div><!-- End .container -->
        </nav>

        <div class="container">
            <ul class="checkout-progress-bar">
                <li class="active">
                    <span>Nhập Thông Tin </span>
                </li>
                <li>
                    <span>Thành Công</span>
                </li>
            </ul>
            <div class="row">
                <div class="col-lg-8">
                    <ul class="checkout-steps">
                        <li>
                            <h2 class="step-title">Đặt Hàng</h2>



                            <form action="#">
                                <div class="form-group required-field">
                                    <label>Họ Và Tên </label>
                                    <input type="text" class="form-control" required>
                                </div><!-- End .form-group -->

                                <div class="form-group required-field">
                                    <label>Số Điện Thoại </label>
                                    <input type="number" class="form-control" required>
                                </div><!-- End .form-group -->

                                <div class="form-group">
                                    <label>Gmail </label>
                                    <input type="email" class="form-control">
                                </div><!-- End .form-group -->

                                <div class="form-group required-field">
                                    <label>Địa Chỉ</label>
                                    <input type="text" class="form-control" required>
                                </div><!-- End .form-group -->
                                <div class="form-group">
                                        <a href="<?php echo e(route('trangchu.pages.thanhcong')); ?>"  class="btn btn-primary">Đặt Hàng</a>
                                </div><!-- End .form-group -->


                            </form>
                        </li>


                    </ul>
                </div><!-- End .col-lg-8 -->

                <div class="col-lg-4">
                    <div class="order-summary">
                            <h3 style="text-align:center;font-weight:600;">Danh Mục</h3>

                        <h4>
                            <a data-toggle="collapse" href="#order-cart-section" class="collapsed" role="button" aria-expanded="false" aria-controls="order-cart-section">Sản Phẩm</a>
                        </h4>

                        <div class="collapse" id="order-cart-section">
                            <table class="table table-mini-cart">
                                <tbody>
                                        <script>
                                                var decodedCookie = decodeURIComponent(document.cookie);
                                                var ca = decodedCookie.split(';');

                                                for(var i = 0; i < ca.length; i++) {
                                                    if(ca[i].indexOf('soLuong')>0){
                                                        var item = JSON.parse(ca[i].substring(ca[i].indexOf('=')+1));
                                                        document.write('<tr>');
                                                        document.write('<td class="product-col">');
                                                        document.write('<figure class="product-image-container">');
                                                        document.write('<a class="product-image"><img src="upload/'+item.img+'"></a>');
                                                        document.write('</figure>');
                                                        document.write(' <div>');
                                                        document.write(' <h2 class="product-title">Số Lượng : '+item.soLuong+'</h2>');
                                                        document.write('</div>');
                                                        document.write(' </td>');
                                                        document.write('<td class="price-col">'+formatNumber(item.gia * item.soLuong)+'.vnđ</td>');
                                                        document.write(' </tr>');


                                                    }
                                                }

                                                function formatNumber(num) {
                                                    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
                                                }



                                            </script>


                                </tbody>
                            </table>
                        </div><!-- End #order-cart-section -->
                    </div><!-- End .order-summary -->
                </div><!-- End .col-lg-4 -->
            </div><!-- End .row -->


        </div><!-- End .container -->

        <div class="mb-6"></div><!-- margin -->
    </main><!-- End .main -->

<?php $__env->stopSection(); ?> <?php $__env->startSection('meta'); ?>
<title>Du Lịch Lý Sơn - Thuê Xe Đà Nẵng - Khách Sạn Lý Sơn</title>
<meta name="keywords" content="" />
<meta name="description" content='' />
<!--meta facebook-->
<meta property="og:title" content="Du Lịch Lý Sơn - Tour Lý Sơn - Thuê Xe Đà Nẵng" />
<meta property="og:description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta property="og:image" content="travel/images/dulich.jpg" />
<!--meta google-->
<meta itemprop="name" content="du lịch lý sơn chuyên tổ chức các tour du lịch lý sơn , đà nẵng , hội an , huế và cho thuê xe du lịch" />
<meta itemprop="description" content="lysonvn là kênh thông tin online hổ trợ đặt tour , đặt phòng khách sạn cho thuê xe giá rẻ khi đi du lịch lý sơn , đà nẵng , hội an , huế và nhận đặt vé tàu khi đi lý sơn" />
<meta itemprop="image" content="travel/images/dulich.jpg" />
<meta name="og:url" content="<?php echo e(route('trangchu.pages.trangchu')); ?>" /> <?php $__env->stopSection(); ?>

<?php echo $__env->make('trangchu.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-sauna\resources\views/trangchu/pages/checkout.blade.php ENDPATH**/ ?>