<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
         <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
      </div>
      <?php endif; ?>
      <!-- DATA TABLE -->
      <div class="card">
         <div class="card-header">
            <strong>Sửa Sản Phẩm</strong>
         </div>
         <div class="card-body card-block">
            <form action=""  enctype="multipart/form-data" method="POST" class="form-horizontal">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Tên Sản Phẩm</label><br><br>
                     <input type="text" id="text-input" name="tenSP" value="<?php echo e($sanpham->tenSP); ?>" placeholder="Nhập tên sản phẩm" class="form-control">
                  </div>
               </div>

               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Tóm Tắt</label><br>
                     <input type="text" id="text-input" name="tomTat" value="<?php echo e($sanpham->tomTat); ?>" placeholder="Nhập tóm tắt" class="form-control">
                  </div>
               </div>
               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Keyword Meta (SEO)</label><br>
                     <input type="text" id="text-input" name="keyword" value="<?php echo e($sanpham->keyword); ?>" placeholder="Nhập giá sản phẩm" class="form-control">
                  </div>
               </div>

               <div class="row form-group">
                    <div class="col-12 col-md-12">
                       <label class="badge badge-info">Giá Sản Phẩm</label><br>
                       <input type="number" id="text-input" name="gia" value="<?php echo e($sanpham->gia); ?>" placeholder="Nhập giá sản phẩm" class="form-control">
                    </div>

                 </div>

               <div class="row form-group">
                    <div class="col-3 col-md-3">
                            <label class="badge badge-info">Chọn Hình Chính</label><br><br>
                            <input type="file" style="width:200px" name="img" value="<?php echo e(old('img')); ?>">
                         </div>
                  <div class="col-3 col-md-3">
                        <label class="badge badge-info">Chọn Hình Phụ 1 (600px - 600px)</label><br><br>
                        <input type="file" style="width:200px" name="img1" value="<?php echo e(old('img1')); ?>">
                  </div>
                  <div class="col-3 col-md-3">
                        <label class="badge badge-info">Chọn Hình Phụ 2 (600px - 600px)</label><br><br>
                        <input type="file" style="width:200px" name="img2" value="<?php echo e(old('img2')); ?>">
                  </div>
                  <div class="col-3 col-md-3">
                        <label class="badge badge-info">Chọn Hình Phụ 3 (600px - 600px)</label><br><br>
                        <input type="file" style="width:200px" name="img3" value="<?php echo e(old('img3')); ?>">
                  </div>
               </div>

               <div class="row form-group">
                    <div class="col-3 col-md-3">
                            <img src="/upload/<?php echo e($sanpham->img); ?>" width="200px" height="150px" alt="salme">
                         </div>
                  <div class="col-3 col-md-3">
                        <img src="/upload/<?php echo e($sanpham->img1); ?>" width="200px" height="150px" alt="salme">
                  </div>
                  <div class="col-3 col-md-3">
                        <img src="/upload/<?php echo e($sanpham->img2); ?>" width="200px" height="150px" alt="salme">
                  </div>
                  <div class="col-3 col-md-3">
                        <img src="/upload/<?php echo e($sanpham->img3); ?>" width="200px" height="150px" alt="salme">
                  </div>
               </div>
                <br>
               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Chi Tiết Sản Phẩm</label><br>
                     <textarea  id="editor1" rows="5" placeholder="Nhập nội dung" class="form-control" name="productDetail"><?php echo e($sanpham->productDetail); ?></textarea>
                  </div>
               </div>
               <div class="row form-group">
                  <div class="col-6 col-md-6">
                     <label class="badge badge-info">Loại Sản Phẩm</label><br>
                     <select name="maLoaiSanPham" class="form-control">
                        <?php $__currentLoopData = $loaisanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  <?php if($sanpham->maLoaiSanPham == $item->id): ?> <?php echo e("selected"); ?> <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->tenLoaiSanPham); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="50">Phòng Xông Hơi Đá Muối Hymalaya</option>
                     </select>
                  </div>
                  <div class="col-6 col-md-6">
                        <label class="badge badge-info">Mặt Hàng</label><br>
                        <select name="maSanPham" class="form-control">
                           <?php $__currentLoopData = $mathang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option  <?php if($sanpham->maSanPham == $item->id): ?> <?php echo e("selected"); ?> <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->tenMatHang); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <option value="0">Không</option>
                        </select>
                     </div>
               </div>
               <div class="card-footer">
                  <button type="submit" class="btn btn-success btn-fw">
                  Sửa
                  </button>
                  <a href="<?php echo e(route('admin.pages.sanpham.danhsach')); ?>" class="btn btn-info btn-fw">
                  Quay về
                  </a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-sauna\resources\views/admin/pages/sanpham/sua.blade.php ENDPATH**/ ?>