@extends('admin.menu.master')

@section('noidung')

<h2> hello admin</h2>

@endsection
