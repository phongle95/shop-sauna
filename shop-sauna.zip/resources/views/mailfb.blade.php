<h3>Tên Khách Hàng : {{$name}}</h3>
<h3>Số Điện Thoại : {{$sdt}}</h3>
<h3>Địa Chỉ Email : {{$email}}</h3>
<h3>Địa Chỉ: {{$diachi}}</h3>
